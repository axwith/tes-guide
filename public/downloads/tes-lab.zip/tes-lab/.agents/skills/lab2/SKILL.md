---
name: lab2
description: 테스 Codex 교육 2교시 안내. `@lab2` 스킬을 사용할 때 읽는다. 과정(1 연구소 장비 런 데이터 / 2 혼합-운영 / 3 혼합-재무)을 번호로 고르게 한 뒤, 업무 파악 → 기획 → 만들기(분석·시각화) → 검토 → 개선(조정·고치기·보고) STEP을 블록마다 설명→복사용 요청문→확인·모범 결과 순서로 멈춰 가며 안내한다.
---

# lab2 — 2교시 · 과정별 데이터 실습

**먼저 `.agents/skills/_common/stop-protocol.md`를 읽고 그 진행 규칙을 지킨다.** 블록마다 A → 멈춤 → B(요청문마다 멈춤) → C → 멈춤.

## 시작
1. `progress.json`을 연다(없으면 stop-protocol 기본값으로 만든다).
2. `current_lab`이 `"lab2"`이고 `current_block`이 있으면 stop-protocol의 "다시 들어왔을 때" 번호 선택지를 보여 주고 멈춘다.
3. 아니면 `current_lab = "lab2"`, `current_block = "block0"`으로 적고 `references/block0-start.md`의 A를 한다(전체 보기 + 과정 고르기 질문). 과정을 고르면 block0의 B(자동 준비)를 한다.

## 과정과 블록 파일

| 번호 | 과정 | `track` | 블록 파일 | 작업 폴더 |
|---|---|---|---|---|
| 1 | 연구소 — 장비 런 데이터(막 두께) | `research` | `references/track-research.md` | `2교시-연구소/` |
| 2 | 혼합직무 — 운영(출하·CS·불량) | `ops` | `references/track-ops.md` | `2교시-운영/` |
| 3 | 혼합직무 — 재무(장비사 5곳 실적) | `finance` | `references/track-finance.md` | `2교시-재무/` |

과정 블록 파일 안에는 블록이 `## block1` … `## block7`로 나뉘고, 블록마다 `### A`, `### B`, `### C` 절이 있다. stop-protocol의 "블록 파일의 A 절"은 이 `### A`를 뜻한다. 정리는 공통 `references/block8-wrap.md`.

## 블록 (세 과정 공통 순서 = 강사 화면 순서)

| 블록 | STEP | 5단계 | 강사 시간 |
|---|---|---|---|
| block0 | 훅·과정 고르기 | — | 0–2분 |
| block1 | STEP 1 | ① 업무 파악 | 2–6분 |
| block2 | STEP 2 | ② 기획 | 6–13분 |
| block3 | STEP 3 | ③ 만들기 — 분석 | 13–21분 |
| block4 | STEP 4 | ③ 만들기 — 시각화 | 21–29분 |
| block5 | STEP 5 | ④ 검토 | 29–36분 |
| block6 | STEP 6 | ⑤ 개선 — 조정(연구소) / 고치기(혼합) | 36–44분 |
| block7 | STEP 7 | ⑤ 개선 — 고치기·보고(연구소) / 한 장 보고(혼합) | 44–48분 |
| block8 | 정리 | — | 48–50분 |

## 진행 규칙 (2교시 추가)
- 요청문은 블록 파일 문구를 **글자 그대로** 코드 블록으로 보여 준다. 모든 STEP을 **같은 대화**에서 이어 한다(앞 결과를 이어 쓰기 때문).
- 참가자가 붙여 넣은 요청문을 실행할 때는 **작업 폴더의 `AGENTS.md`를 먼저 읽고** 그 규칙대로 한다. 경로 `data/`, `outputs/`, `tools/`는 작업 폴더 기준이다. 결과는 작업 폴더의 `outputs/`에 저장한다.
- 작업 폴더 `AGENTS.md`가 가리키는 스킬(대시보드·추이·분포 그림)은 그 `SKILL.md`를 열어 따른다.
- 요청문 하나는 3~5분 안에 끝내는 것을 목표로 한다. 계산·그림은 스크립트 하나로 한 번에.
- "건너뛰기"면 블록 파일의 `모범 결과` 파일을 작업 폴더 `outputs/`로 복사한다. 앞 STEP 결과가 없으면 앞 STEP 모범 결과도 함께 복사한다(블록 파일에 적힌 목록).
- block8의 C가 끝나면 `done`에 `"lab2"`를 추가하고 `current_lab`·`current_block`·`phase`를 `null`로 적는다(`track`은 남긴다 — 3교시에서 "2교시에 한 분석"을 찾을 때 쓴다).
