---
name: lab1
description: 테스 Codex 교육 1교시 안내. `@lab1` 스킬을 사용할 때 읽는다. 오늘 흐름과 5단계 되짚기 → 가짜 다운로드 폴더 정리로 5단계 한 바퀴(지우기 거부 연습 포함) → gptaku Codex 플러그인 설치·사용(insane-search, insane-research) → 정리를 블록마다 설명→요청문→확인 순서로 멈춰 가며 안내한다.
---

# lab1 — 1교시 · Codex 시작하기

**먼저 `.agents/skills/_common/stop-protocol.md`를 읽고 그 진행 규칙을 지킨다.** 블록마다 A → 멈춤 → B(요청문마다 멈춤) → C → 멈춤.

## 블록

| 블록 | 파일 | 5단계 | 강사 시간 |
|---|---|---|---|
| block0 오늘 흐름·5단계 되짚기 | `references/block0-start.md` | — | 15–17분 무렵 |
| block1 다운로드 폴더 정리 실습 | `references/block1-downloads.md` | 업무 파악→기획→만들기→검토→개선 한 바퀴 | 17–40분 |
| block2 플러그인 설치하고 써 보기 | `references/block2-plugins.md` | 만들기·검토 | 40–48분 |
| block3 정리 | `references/block3-wrap.md` | — | 48–50분 |

## 시작
1. `progress.json`을 연다(없으면 `_common/stop-protocol.md`의 기본값으로 만든다).
2. **git 준비 (Windows만, `progress.json`의 `git`이 경로나 `"ok"`가 아닐 때만).** 플러그인 마켓 등록에 git이 필요하다. 답을 쓰기 전에 PowerShell에서 `git --version`을 실행한다.
   - 되면 `git = "ok"`로 적는다.
   - 안 되면 `powershell -NoProfile -ExecutionPolicy Bypass -File .agents\skills\lab1\scripts\ensure-git.ps1`을 **승인을 요청해** 실행한다(Git for Windows를 사용자 범위로 설치. 관리자 권한은 쓰지 않는다. 일시 오류는 스크립트가 다시 시도하며 최대 5분). 승인 이유는 `플러그인 마켓 등록에 필요한 git을 준비합니다`로 적는다.
   - 출력 마지막 줄이 `GIT_OK <경로>`면 `git`에 그 경로를, `GIT_FAIL`이면 `"fail"`을, 참가자가 승인을 거부하면 `"skip"`을 적는다.
   - 결과는 화면에 말하지 않는다(실패해도). 그대로 다음 순서로 간다. Mac은 이 단계를 건너뛴다.
3. `current_lab`이 `"lab1"`이고 `current_block`이 있으면 stop-protocol의 "다시 들어왔을 때" 번호 선택지를 보여 주고 멈춘다.
4. 아니면 `current_lab = "lab1"`, `current_block = "block0"`, `phase = null`로 적고 아래 **전체 보기**를 그대로 보여 준 뒤, 바로 이어서 block0의 A를 한다(전체 보기 + block0 A가 첫 답 하나다).

## 전체 보기 (그대로 출력)

```
1교시 — Codex 시작하기 (50분)

블록 0. 오늘 흐름과 5단계 되짚기
블록 1. 다운로드 폴더 정리 실습로 5단계 한 바퀴
        업무 파악 → 기획 → 만들기 → 검토 → 개선, 그리고 "지워 줘"를 거절해 보기
블록 2. 플러그인 설치하고 써 보기 — insane-search(뉴스 표), insane-research(짧은 보고서)
블록 3. 정리 — 오늘 남은 파일 보기

끝나면 남는 것: 1교시-실습/계획.md, 정리된 downloads 폴더, 정리결과.md, 설치된 플러그인 2개
진행: 설명 → '다음' → 요청문 복사해 보내기 → 결과 확인 → '다음'
막히면 '도와줘', 시간이 모자라면 '건너뛰기'(모범 결과로 넘어감)
```

## 블록 진행
- 블록 파일의 `## A`, `## B`, `## C` 절을 단계에 맞춰 읽는다. 한 턴에 한 절만.
- B의 요청문은 블록 파일에 적힌 문구를 **글자 그대로** 코드 블록으로 보여 준다(강사 화면과 같아야 한다).
- block3의 C가 끝나면 `done`에 `"lab1"`을 추가하고, `current_lab`·`current_block`·`phase`를 `null`로 적는다. 마지막 줄: `쉬는 시간 뒤 2교시에 '@lab2'이라고 보내세요.`
