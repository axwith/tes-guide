# block2 — 플러그인 설치하고 써 보기 (8분)

플러그인 = Codex에 기능 묶음을 더하는 것. 오늘은 gptaku Codex 마켓(`fivetaku/gptaku-plugins-codex`, 앱 목록 이름 **GPTaku Codex**)에서 두 개를 설치한다.

| 플러그인(설치 이름) | 앱 목록 이름 | 하는 일 |
|---|---|---|
| `insane-search-codex` | Insane Search Codex | 막힌 공개 페이지·공시·뉴스를 여러 방법으로 열어 읽기 |
| `insane-research-codex` | Insane Research Codex | 출처를 대조하며 리서치 보고서 쓰기 |

실측(2026-11-23, Mac, Codex CLI 0.171, 격리된 설정으로): 마켓 등록 4초, CLI 설치 즉시, insane-search 뉴스 표 64초, insane-research 한 장 보고서 217초(결과 `RESEARCH/<주제>/outputs/one_page_report.md`). 요청문에 플러그인 이름을 넣어야 플러그인이 쓰인다 — 이름 없이 "뉴스 찾아 줘"만 보내면 Codex 기본 웹 검색으로 답한다(그것도 표는 나온다).

## A
보여 줄 내용:
```
플러그인 설치하고 써 보기 (8분)
1. 마켓 확인 — 3교시 설치기가 미리 등록해 두었는지 Codex가 확인합니다
2. 설치 — 앱에서 /plugins → GPTaku Codex → Insane Search Codex, Insane Research Codex 설치
3. 새 대화에서 써 보기 — 업계 뉴스 표, 짧은 보고서
4. 확인 — "실제로 열어서 확인한 것만" 파일 경로와 출처 표
플러그인 이름보다 남은 파일과 근거가 중요합니다.
설치가 막히면 강사 화면 시연을 보고 넘어갑니다.
```

## B

### 자동 확인 (B 첫 답에서 먼저, 읽기만)
1. 앱에 들어 있는 Codex 명령을 찾는다. 찾은 첫 경로를 쓴다.
   - Mac: `command -v codex` → 없으면 `/Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex` → `/Applications/Codex.app/Contents/Resources/codex`
   - Windows(PowerShell): `(Get-Command codex -ErrorAction SilentlyContinue).Source` → 없으면 `Join-Path (Get-AppxPackage OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1).InstallLocation 'app\resources\codex.exe'`
2. `<codex> plugin marketplace list` 로 `gptaku-codex`가 있는지, `<codex> plugin list` 로 `insane-search-codex@gptaku-codex`·`insane-research-codex@gptaku-codex`가 `installed`인지 본다.
3. 한 줄 보고. 예: `마켓 등록됨, 플러그인 2개 아직 설치 안 됨.` 명령을 못 찾으면 `Codex 명령을 찾지 못했습니다. 앱의 /plugins 화면으로 진행합니다.`
4. 상태에 맞는 첫 요청문을 보여 주고 멈춘다(마켓이 이미 있으면 ①을 건너뛰고 ②부터).

### 요청문 (차례대로, 하나 보여 주고 멈춤)

**① 마켓 등록 (등록돼 있으면 건너뜀)**
```
gptaku Codex 플러그인 마켓을 등록해 줘
```
실행: 위에서 찾은 명령으로 `<codex> plugin marketplace add https://github.com/fivetaku/gptaku-plugins-codex.git`. 인터넷과 폴더 밖(사용자 Codex 설정)을 쓰므로 **승인을 요청해 실행**한다. 결과 한 줄 `Added marketplace gptaku-codex`를 보여 준다.
확인할 것: 승인 창이 뜨면 명령에 `gptaku-plugins-codex`가 있는지 읽고 승인합니다.

**② 설치 — 앱 화면에서**
요청문 대신 이렇게 안내한다:
```
대화창에 /plugins 를 입력 → GPTaku Codex 선택 → Insane Search Codex 설치 → Insane Research Codex 설치
목록에 GPTaku Codex가 없으면 앱을 완전히 끄고 다시 켠 뒤 /plugins 를 다시 엽니다.
화면에서 설치가 안 되면 아래 문장을 보내세요:
```
```
insane-search-codex랑 insane-research-codex 플러그인을 설치해 줘
```
실행(문장을 받았을 때): `<codex> plugin add insane-search-codex@gptaku-codex`, `<codex> plugin add insane-research-codex@gptaku-codex` (승인을 요청해 실행). 끝나면 `<codex> plugin list`로 두 줄이 `installed, enabled`인지 보여 준다.
확인할 것: 두 플러그인이 설치됨으로 보이는지. 끝나면 **왼쪽 위 새 대화**를 열고(같은 폴더), 다음 요청문부터는 새 대화에 보냅니다. 플러그인은 새 대화부터 쓰입니다.

**③ insane-search — 업계 뉴스 표 (새 대화에서)**
```
insane-search로 오늘 반도체 장비 업계 뉴스 5개를 찾아서 제목·날짜·한 줄 요약·주소로 표로 정리해 줘
```
확인할 것: 표의 주소 하나를 눌러 실제 기사가 열리는지, 날짜가 기사와 같은지. 인터넷 사용 승인 창이 뜨면 승인합니다. (실측 약 1분)

**④ insane-research — 짧은 보고서 (새 대화에서)**
```
insane-research로 HBM 투자 확대가 증착 장비 수요에 어떤 영향을 주는지 출처 3개 이상으로 한 장 보고서 써 줘
```
확인할 것: 범위를 묻는 번호 선택지가 나오면 `1`. 실측 약 4분입니다. 5분이 넘으면 기다리지 말고 ⑤로 가거나 강사 화면 결과를 봅니다. 결과는 `RESEARCH/<주제>/outputs/` 에 쌓입니다(보고서에 투자 판단 문장이 섞이면 업무 참고용으로만 봅니다).

**⑤ 확인 요청 (새 대화에서)**
```
방금 만든 파일 경로와 출처를 표로 보여 줘. 실제로 열어서 확인한 것만
```
확인할 것: 표에 파일 경로와 출처 주소가 있고, 열어 보지 않은 것은 빠졌는지. 끝나면 처음 대화로 돌아가 `다음`을 보냅니다(새 대화에서 `1교시 시작` → `1. 이어서 하기`도 됩니다).

### 막히면
| 증상 | 이렇게 말해 보세요 / 할 일 |
|---|---|
| 승인 창을 거부해 버렸다 | 같은 요청문을 다시 보내고 이번엔 승인 |
| `/plugins`에 GPTaku Codex가 없다 | 앱을 완전히 끄고 다시 켬 → 그래도 없으면 `gptaku Codex 플러그인 마켓을 등록해 줘` |
| 회사망에서 github.com이 막혔다 | 설치는 건너뛰고 강사 화면 시연을 봅니다. ③은 `오늘 반도체 장비 업계 뉴스 5개를 찾아서 …`(플러그인 이름 없이)로 기본 웹 검색을 써 봅니다 |
| 플러그인 이름을 넣었는데 안 쓰인다 | 새 대화에서 보냈는지 확인. 아니면 새 대화를 열고 다시 |
| insane-research가 계속 돈다 | 기다리지 말고 ⑤로. 결과는 나중에 `RESEARCH/`에서 봅니다 |
| Windows에서 insane-search가 bash·python 오류를 낸다 | 미검증 환경입니다. 강사 화면 시연으로 넘어가고, 같은 요청을 플러그인 이름 없이 보내 봅니다 |

### 모범 결과
없음(뉴스는 날마다 다르다). 강사 화면 결과로 비교한다.

## C
- 확인 체크: ① 플러그인 2개 설치됨(`/plugins` 또는 `codex plugin list`) ② 뉴스 표 5줄과 주소 ③ 확인 요청에 "열어서 확인한 것만" 표
- 핵심: "플러그인 이름보다 남은 파일과 근거가 중요합니다. 출처는 내가 하나 눌러 봅니다."
- 덧붙임: 3교시에 쓰는 skillers-suda(스킬 설계)는 3교시에 소개합니다. 시간이 남으면 pumasi 플러그인의 이미지 기능으로 보고서 표지 그림 1장을 만들어 볼 수 있습니다.
