# block2 — 플러그인 설치

플러그인 = Codex에 기능 묶음을 더하는 것. GPTaku 통합 플러그인 마켓(`https://github.com/fivetaku/gptaku_plugins`, 마켓 이름 `gptaku-plugins`)을 등록하고, 목록을 보며 플러그인을 한 줄씩 소개한 뒤 오늘 쓸 두 개(insane-research, pumasi)를 설치한다. insane-search는 선택.

| 플러그인 | 설치 식별자 | 오늘 쓰는 곳 | Codex 안의 스킬 이름 |
|---|---|---|---|
| insane-research (필수) | `insane-research@gptaku-plugins` | block3 ① 오늘 이슈 찾기 | `insane-research:insane-research-main` |
| pumasi (필수) | `pumasi@gptaku-plugins` | block3 ③ 이슈 그림 | `pumasi:image` |
| insane-search (선택) | `insane-search@gptaku-plugins` | 잘 안 열리는 사이트를 읽을 때 | `insane-search:insane-search` |

강사용 실측(2026-11-23, Mac, Codex CLI 0.171.0, 격리된 설정): `codex plugin marketplace add https://github.com/fivetaku/gptaku_plugins.git` 약 2초, `codex plugin add insane-research@gptaku-plugins`·`pumasi@gptaku-plugins` 각 약 1.5초. 마켓 목록은 22개. `gptaku-core`는 Codex에서 자동으로 설치되지 않았고(`not installed`), 그 상태로 block3 ③ 그림이 만들어졌다.
앱 화면 경로(오너 확인): 좌측 하단 계정(아이디) 아이콘 → 설정 → 통합 → 플러그인 → 우측 상단 '추가' → '마켓플레이스 추가' → 저장소 주소 입력 → 등록. 설치는 같은 플러그인 화면의 목록에서 한다. 이 밖의 버튼 이름은 지어내지 않는다.

## A
보여 줄 내용(이 글 그대로):
```
플러그인 설치
1. 마켓 등록 — 앱 설정 화면에서 GPTaku 플러그인 마켓을 등록합니다
2. 목록 보기 — 어떤 플러그인이 있는지 한 줄씩 봅니다
3. 설치 — insane-research, pumasi 두 개(insane-search는 원하면)
4. 새 대화 — 플러그인은 새 대화부터 쓰입니다

끝나면 남는 것: 설치된 플러그인 2개(insane-search까지 하면 3개)
설치가 막히면 강사 화면 시연을 보고 넘어갑니다.
```
이어서 아래 표를 그대로 보여 준다(표 5줄 제한의 예외 — 목록을 보며 설명하는 단계다).

GPTaku 플러그인 한눈에 보기

| 플러그인 | 한 줄 설명 |
|---|---|
| insane-research | 여러 출처를 찾아 조사 보고서를 만들어 줍니다 |
| pumasi | 그림·썸네일·포스터 같은 이미지를 만들어 줍니다(큰 코딩 작업 나눠 맡기기도 가능) |
| insane-search | 잘 안 열리는 사이트(X, 레딧, 네이버, 유튜브 등)의 글·영상 내용을 가져와 읽습니다 |
| docs-guide | 프로그램·도구의 공식 문서를 찾아 쉽게 설명해 줍니다 |
| show-me-the-prd | 아이디어를 말하면 기획서(PRD) 초안을 바로 써 줍니다 |
| skillers-suda | 반복하는 일을 Codex 스킬로 만들어 줍니다 |
| kkirikkiri | 여러 AI 에이전트로 팀을 꾸려 일을 나눠 맡깁니다 |
| nopal | Gmail·캘린더·드라이브·문서·시트를 말로 다룹니다 |
| insane-design | 웹사이트의 디자인을 뽑아 내 화면에 적용합니다 |
| sangse | 상품 정보로 쇼핑몰 상세페이지 이미지를 만듭니다 |
| git-teacher | Git·GitHub를 처음 쓰는 사람에게 쉽게 알려 줍니다 |
| vibe-sunsang | 내 AI 사용 기록을 보고 성장 코칭을 해 줍니다 |
| insane-review | ChatGPT Pro에게 코드·질문을 보내 다른 의견을 받아 옵니다 |
| insane-loop | 아이디어 → 기획 → 완성까지 검증하며 반복합니다 |
| goaljaby | 기획서를 목표 실행 문서로 바꿔 끝까지 진행시킵니다 |
| playmaker | 목표 진행 상황을 카드 보드로 보여 줍니다 |
| golla-jev | 업무에서 '고르는 순간'을 찾아 자동 판단 흐름을 설계합니다 |
| dd | 방금 복사한 글·이미지를 붙여 넣기 없이 바로 넘깁니다 |
| tikeytaka | 흩어진 API 키를 한곳에 안전하게 모아 관리합니다 |
| ddiring | 작업이 끝나면 어느 창의 어떤 일이 끝났는지 알려 줍니다 |
| gaseo | 작업 세션을 Paseo 앱에 등록해 다른 기기에서 이어 합니다 |
| gptaku-core | 다른 플러그인이 함께 쓰는 기본 묶음(오늘은 설치하지 않아도 됩니다) |

오늘은 위 두 줄(insane-research, pumasi)을 설치해 block3에서 이어 씁니다. 나머지는 필요할 때 같은 화면에서 설치합니다.

## B

### 자동 확인 (B 첫 답에서 먼저, 읽기만)
1. 앱에 들어 있는 Codex 명령을 찾는다. 찾은 첫 경로를 쓴다.
   - Mac: `command -v codex` → 없으면 `/Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex` → `/Applications/Codex.app/Contents/Resources/codex`
   - Windows(PowerShell): `(Get-Command codex -ErrorAction SilentlyContinue).Source` → 없으면 `Join-Path (Get-AppxPackage OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1).InstallLocation 'app\resources\codex.exe'` → 그래도 없으면(앱 패키지 이름이 다를 수 있다) `Get-AppxPackage *OpenAI*`·`Get-AppxPackage *ChatGPT*`의 InstallLocation 아래에서 `codex.exe`를 찾는다(`Get-ChildItem -Recurse -Filter codex.exe`, 첫 번째)
2. `<codex> plugin marketplace list`로 `gptaku-plugins`가 있는지, `<codex> plugin list`로 `insane-research@gptaku-plugins`·`pumasi@gptaku-plugins`(필수)와 `insane-search@gptaku-plugins`(선택)가 `installed, enabled`인지 본다.
3. 한 줄 보고. 예: `마켓 등록 안 됨, 필수 플러그인 2개 중 0개 설치됨.` 명령을 못 찾으면 `Codex 명령을 찾지 못했습니다. 앱의 설정 화면으로 진행합니다.` 이때는 아래 백업 문장도 실행할 수 없으므로, 화면에서 막히면 강사 화면 시연을 보고 넘어가도록 안내한다.
4. 상태에 맞는 첫 안내를 보여 주고 멈춘다(마켓이 이미 있으면 ①을 건너뛰고 ②부터, 필수 두 개가 설치돼 있으면 ③으로).

### 안내 (차례대로, 하나 보여 주고 멈춤)
①·②는 앱 화면에서 하는 일이다. 안내 뒤 참가자가 `했어요`·`다음`을 보내면(또는 백업 문장 실행이 끝나면) C로 가지 말고 다음 안내로 간다(① → ② → ③). block2의 B 끝은 ③ 안내다. `했어요`를 받으면 자동 확인처럼 `plugin marketplace list`·`plugin list`를 읽어 한 줄로 확인한 뒤 다음 안내를 보여 준다(명령을 못 찾으면 확인 없이 다음 안내).


**① 마켓 등록 (등록돼 있으면 건너뜀)**
요청문 대신 이렇게 안내한다:
```
앱 화면에서 마켓을 등록합니다.
1. 왼쪽 아래 계정(아이디) 아이콘을 누르고 설정을 엽니다.
2. 통합 → 플러그인으로 갑니다.
3. 오른쪽 위 '추가'를 누르고 '마켓플레이스 추가'를 고릅니다.
4. 저장소 주소에 https://github.com/fivetaku/gptaku_plugins 를 넣고 등록합니다.
다 했으면 대화창에 '했어요'를 보내세요. 화면에서 막히면 아래 문장을 보내세요.
```
```
GPTaku 플러그인 마켓을 등록해 줘
```
실행(문장을 받았을 때): 위에서 찾은 명령으로 `<codex> plugin marketplace add https://github.com/fivetaku/gptaku_plugins.git`. 인터넷과 폴더 밖(사용자 Codex 설정)을 쓰므로 **승인을 요청해 실행**한다. 이어서 `<codex> plugin marketplace list`로 한 줄 확인한다.
확인할 것: 플러그인 화면 목록에 GPTaku 플러그인들이 보이는지. 문장으로 했다면 승인 창의 명령에 `gptaku_plugins`가 있는지 읽고 승인합니다.

**② 목록 보며 설치**
요청문 대신 이렇게 안내한다:
```
같은 플러그인 화면 목록에서 GPTaku 플러그인들을 위에서 아래로 훑어봅니다(한 줄 설명은 위 표).
insane-research와 pumasi 두 개를 설치합니다. insane-search는 원하면 같이 설치합니다.
다 했으면 대화창에 '했어요'를 보내세요. 화면에서 찾기 어렵거나 설치가 안 되면 아래 문장을 보내세요.
```
```
insane-research, pumasi 플러그인을 설치해 줘
```
실행(문장을 받았을 때): `<codex> plugin add insane-research@gptaku-plugins`, `<codex> plugin add pumasi@gptaku-plugins` (승인을 요청해 실행). 참가자가 insane-search도 말했으면 `<codex> plugin add insane-search@gptaku-plugins`도. 끝나면 `<codex> plugin list`에서 해당 줄이 `installed, enabled`인지 보여 준다.
확인할 것: insane-research와 pumasi가 설치됨으로 보이는지.

**③ 새 대화로 옮기기**
요청문 대신 이렇게 안내하고, 보내기 전에 `progress.json`을 `current_block = "block2"`, `phase = "C"`로 적는다:
```
플러그인은 새 대화부터 쓰입니다.
1. 왼쪽 목록에서 프로젝트 이름(1교시-Codex-시작하기)을 눌러 새 대화를 엽니다.
2. 새 대화에 @lab1 을 보냅니다.
3. "지난번에 … 멈추셨습니다"가 나오면 1(이어서 하기)을 보냅니다.
이제부터는 새 대화에서 진행합니다.
```

### 막히면
| 증상 | 이렇게 말해 보세요 / 할 일 |
|---|---|
| 승인 창을 거부해 버렸다 | 같은 문장을 다시 보내고 이번엔 승인 |
| 플러그인 화면에 GPTaku 플러그인이 없다 | 앱을 완전히 끄고 다시 켬 → 그래도 없으면 `GPTaku 플러그인 마켓을 등록해 줘` |
| 회사망에서 github.com이 막혔다 | 설치는 건너뛰고 강사 화면 시연을 봅니다. block3은 플러그인 이름 없이 같은 요청을 보내 기본 기능으로 해 봅니다 |
| 플러그인 이름을 넣었는데 안 쓰인다 | 새 대화에서 보냈는지 확인. 아니면 새 대화를 열고 다시 |

### 모범 결과
없음. 플러그인 화면 또는 `codex plugin list` 결과로 확인한다.

## C
- 확인 체크(직접 확인한다): ① 지금 대화가 새 대화다 ② 이 대화에서 쓸 수 있는 스킬 목록에 `insane-research:insane-research-main`과 `pumasi:image`가 보인다(보이지 않으면 Codex 명령으로 `plugin list`를 읽어 설치 여부를 확인한다) ③ `insane-search`는 설치했으면 "설치됨", 아니면 "선택 — 안 함"
- 핵심: "플러그인은 한 번 설치하면 어느 폴더에서든 씁니다. 요청문에 플러그인 이름을 넣으면 그 기능을 씁니다."
