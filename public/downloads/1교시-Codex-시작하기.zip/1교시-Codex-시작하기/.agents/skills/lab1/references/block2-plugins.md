# block2 — 플러그인 설치

플러그인 = Codex에 기능 묶음을 더하는 것. GPTaku 통합 플러그인 마켓(`https://github.com/fivetaku/gptaku_plugins`, 마켓 이름 `gptaku-plugins`)을 등록하고, 목록을 보며 플러그인을 한 줄씩 소개한 뒤 쓸 만한 13개(gptaku-core, insane-research, pumasi, insane-search, docs-guide, show-me-the-prd, skillers-suda, kkirikkiri, insane-loop, goaljaby, playmaker, tikeytaka, vibe-sunsang)를 모두 설치한다. 실습은 그중 두 개(insane-research, pumasi)만 block3에서 해 본다.

| 플러그인 | 설치 식별자 | 오늘 쓰는 곳 | Codex 안의 스킬 이름 |
|---|---|---|---|
| gptaku-core | `gptaku-core@gptaku-plugins` | 다른 플러그인이 함께 쓰는 기본 묶음 | — |
| insane-research (실습) | `insane-research@gptaku-plugins` | block3 ① 오늘 이슈 찾기 | `insane-research:insane-research-main` |
| pumasi (실습) | `pumasi@gptaku-plugins` | block3 ③ 이슈 그림 | `pumasi:image` |
| insane-search | `insane-search@gptaku-plugins` | 잘 안 열리는 사이트를 읽을 때 | `insane-search:insane-search` |
| docs-guide | `docs-guide@gptaku-plugins` | 프로그램 공식 문서 설명 | `docs-guide:docs-guide` |
| show-me-the-prd | `show-me-the-prd@gptaku-plugins` | 아이디어 → 기획서 | `show-me-the-prd:show-me-the-prd` |
| skillers-suda | `skillers-suda@gptaku-plugins` | 반복 업무 → 스킬 | `skillers-suda:skillers-suda` |
| kkirikkiri | `kkirikkiri@gptaku-plugins` | 여러 에이전트 팀으로 나눠 맡기기 | `kkirikkiri:kkirikkiri` |
| insane-loop | `insane-loop@gptaku-plugins` | 아이디어 → 기획 → 완성까지 검증하며 반복 | `insane-loop:insane-loop` |
| goaljaby | `goaljaby@gptaku-plugins` | 기획서 → 목표 실행 문서 | `goaljaby:goaljaby` |
| playmaker | `playmaker@gptaku-plugins` | 목표 진행 카드 보드 | `playmaker:playmaker` |
| tikeytaka | `tikeytaka@gptaku-plugins` | 나중에 API 키 관리(Windows는 시험 지원) | `tikeytaka:tikeytaka` |
| vibe-sunsang | `vibe-sunsang@gptaku-plugins` | 시간이 남으면 마지막에 내 사용 기록 코칭 | `vibe-sunsang:vibe-sunsang` |

설치 묶음 13개 = 위 표 전부. 마켓의 나머지(nopal·insane-design·sangse·git-teacher·insane-review·golla-jev·dd·ddiring·gaseo)는 오늘 설명도 설치도 하지 않는다.

강사용 실측(2026-11-23, Mac, Codex CLI 0.171.0, 격리된 설정): `codex plugin marketplace add https://github.com/fivetaku/gptaku_plugins.git` 약 2초, `codex plugin add insane-research@gptaku-plugins`·`pumasi@gptaku-plugins` 각 약 1.5초. 마켓 목록은 22개. `gptaku-core`는 Codex에서 자동으로 설치되지 않았고(`not installed`), 그 상태로 block3 ③ 그림이 만들어졌다.
앱 화면 경로(오너 확인): 좌측 하단 계정(아이디) 아이콘 → 설정 → 통합 → 플러그인 → 우측 상단 '추가' → '마켓플레이스 추가' → 저장소 주소 입력 → 등록. 설치는 왼쪽 아이콘 줄의 플러그인 아이콘 → 맞춤 설정 → 플러그인 → '개인용' 탭에서 한다(마켓 등록 직후 '공개' 탭에는 GPTaku가 없다). 이 밖의 버튼 이름은 지어내지 않는다.

## 시작 답

### 자동 확인 (시작 답을 보여 주기 전에 먼저, 읽기만)
0. (Windows) git: `progress.json`의 `git`이 경로나 `"ok"`가 아니면 SKILL.md "시작" 2번의 git 준비를 지금 한 번 더 한다(승인 요청).
   - 이 블록에서 `<codex>` 명령을 실행할 때 `git`이 경로이면 명령 앞에 `$env:Path = '<그 경로의 폴더>;' + $env:Path;`를 붙인다(앱이 git 설치 전에 켜져 있으면 앱과 셸이 새 git을 못 보기 때문).
   - `git`이 경로인데 Codex 셸에서 `git --version`이 안 되면 앱 화면의 마켓 등록도 실패할 가능성이 크다. 이때는 단계 1을 앱 화면 대신 백업 문장으로 시작한다: 화면 안내 자리에 `이 PC는 문장으로 마켓을 등록합니다. 승인 창이 뜨면 명령에 gptaku_plugins가 있는지 보고 승인합니다.` 한 줄을 쓰고, 지금 보낼 말을 단계 1의 백업 문장으로 보여 준다.
1. 앱에 들어 있는 Codex 명령을 찾는다. 찾은 첫 경로를 쓴다.
   - Mac: `command -v codex` → 없으면 `/Applications/ChatGPT.app/Contents/Resources/codex-cli/bin/codex` → `/Applications/Codex.app/Contents/Resources/codex`
   - Windows(PowerShell): `(Get-Command codex -ErrorAction SilentlyContinue).Source` → 없으면 `Join-Path (Get-AppxPackage OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1).InstallLocation 'app\resources\codex.exe'` → 그래도 없으면(앱 패키지 이름이 다를 수 있다) `Get-AppxPackage *OpenAI*`·`Get-AppxPackage *ChatGPT*`의 InstallLocation 아래에서 `codex.exe`를 찾는다(`Get-ChildItem -Recurse -Filter codex.exe`, 첫 번째)
2. `<codex> plugin marketplace list`로 `gptaku-plugins`가 있는지, `<codex> plugin list`로 설치 묶음 13개가 `installed, enabled`인지 본다.
3. 한 줄 보고. 예: `마켓 등록 안 됨, 플러그인 13개 중 0개 설치됨.` 명령을 못 찾으면 `Codex 명령을 찾지 못했습니다. 앱의 설정 화면으로 진행합니다.` 이때는 아래 백업 문장도 실행할 수 없으므로, 화면에서 막히면 강사 화면 시연을 보고 넘어가도록 안내한다.
4. 상태에 맞는 단계부터 시작한다: 마켓이 이미 있으면 단계 1을 건너뛰고 단계 2부터, 13개가 모두 설치돼 있으면 단계 3부터. `step`도 그 번호로 적는다.

설명(이 글 그대로):
```
플러그인 설치
플러그인은 Codex에 기능 묶음을 더하는 것입니다. 앱 설정 화면에서 GPTaku 플러그인 마켓을 등록하고, 목록을 본 뒤 쓸 만한 플러그인 13개를 설치합니다. 실습은 그중 insane-research와 pumasi 두 개로 합니다.
끝나면 남는 것: 설치된 플러그인 13개
```

그 아래 시작하는 단계의 화면 안내와 그 단계의 지금 보낼 말.

## 차례

단계 1·2는 앱 화면에서 하는 일이라 보낼 요청문이 없다. 지금 보낼 말은 `했어요`다. `했어요`를 받으면 자동 확인처럼 `plugin marketplace list`·`plugin list`를 읽어 한 줄로 확인한 뒤 다음 단계 안내를 보여 준다(명령을 못 찾으면 확인 없이 다음 단계). 확인해 보니 아직 안 됐으면 한 줄로 알리고, 지금 보낼 말을 그 단계의 백업 문장으로 바꿔 보여 준다.
참가자가 `도와줘`를 보내거나 화면에서 막혔다고 하면, 지금 보낼 말을 그 단계의 백업 문장으로 바꿔 보여 준다. 백업 문장을 받으면 실제로 실행하고 확인할 것 + 다음 단계 안내를 보여 준다.

### 단계 1. 마켓 등록 (등록돼 있으면 건너뜀)
화면 안내(이 글 그대로):
```
앱 화면에서 마켓을 등록합니다.
1. 왼쪽 아래 계정(아이디) 아이콘을 누르고 설정을 엽니다.
2. 통합 → 플러그인으로 갑니다.
3. 오른쪽 위 '추가'를 누르고 '마켓플레이스 추가'를 고릅니다.
4. 저장소 주소에 https://github.com/fivetaku/gptaku_plugins 를 넣고 등록합니다.
```
지금 보낼 말:
```
했어요
```
백업 문장(막혔을 때만 지금 보낼 말로 보여 준다):
```
GPTaku 플러그인 마켓을 등록해 줘
```
실행(백업 문장을 받았을 때): 위에서 찾은 명령으로 `<codex> plugin marketplace add https://github.com/fivetaku/gptaku_plugins.git`. 인터넷과 폴더 밖(사용자 Codex 설정)을 쓰므로 **승인을 요청해 실행**한다. 이어서 `<codex> plugin marketplace list`로 한 줄 확인한다.
확인할 것: 플러그인 화면 목록에 GPTaku 플러그인들이 보이는지. 문장으로 했다면 승인 창의 명령에 `gptaku_plugins`가 있는지 읽고 승인합니다.

### 단계 2. 목록 보며 설치
한 줄 확인 뒤, 설치 화면 안내 앞에 아래 표를 그대로 보여 준다(표 5줄 제한의 예외 — 목록을 보며 설명하는 단계다. 설치는 아직 하지 않았으므로 오늘 쓰는 곳 칸으로 무엇을 실습에 쓰는지 알려 준다).

GPTaku 플러그인 한눈에 보기

| 플러그인 | 한 줄 설명 | 오늘 쓰는 곳 |
|---|---|---|
| insane-research | 여러 출처를 찾아 조사 보고서를 만들어 줍니다 | 블록 3 오늘 이슈 찾기(실습) |
| pumasi | 그림·썸네일·포스터 같은 이미지를 만들어 줍니다(큰 코딩 작업 나눠 맡기기도 가능) | 블록 3 이슈 그림(실습) |
| insane-search | 잘 안 열리는 사이트(X, 레딧, 네이버, 유튜브 등)의 글·영상 내용을 가져와 읽습니다 | 설치만 |
| docs-guide | 프로그램·도구의 공식 문서를 찾아 쉽게 설명해 줍니다 | 설치만 |
| show-me-the-prd | 아이디어를 말하면 기획서(PRD) 초안을 바로 써 줍니다 | 설치만 |
| skillers-suda | 반복하는 일을 Codex 스킬로 만들어 줍니다 | 설치만 |
| kkirikkiri | 여러 AI 에이전트로 팀을 꾸려 일을 나눠 맡깁니다 | 설치만 |
| vibe-sunsang | 내 AI 사용 기록을 보고 성장 코칭을 해 줍니다 | 시간이 남으면 마지막에 |
| insane-loop | 아이디어 → 기획 → 완성까지 검증하며 반복합니다 | 설치만 |
| goaljaby | 기획서를 목표 실행 문서로 바꿔 끝까지 진행시킵니다 | 설치만 |
| playmaker | 목표 진행 상황을 카드 보드로 보여 줍니다 | 설치만 |
| tikeytaka | 흩어진 API 키를 한곳에 안전하게 모아 관리합니다 | 설치만 |
| gptaku-core | 다른 플러그인이 함께 쓰는 기본 묶음 | 먼저 설치 |

화면 안내(이 글 그대로):
```
같은 플러그인 화면 목록에서 GPTaku 플러그인들을 위에서 아래로 훑어봅니다(한 줄 설명은 위 표).
1. Codex 창 맨 왼쪽 아이콘 줄에서 플러그인 아이콘(위에서 네 번째, 동그라미 속 @ 모양)을 누릅니다. 맞춤 설정 화면이 열립니다.
2. 플러그인 제목 아래 '개인용' 탭 → GPTaku plugins 목록('… 등 더 보기'로 전체)에서 아래 13개를 + 로 설치합니다.
3. '공개' 탭의 Gmail·Teams·Canva 같은 플러그인은 나중에 필요한 것만 같은 방법으로 설치해 씁니다.
아래 13개를 설치합니다: gptaku-core, insane-research, pumasi, insane-search, docs-guide, show-me-the-prd, skillers-suda, kkirikkiri, insane-loop, goaljaby, playmaker, tikeytaka, vibe-sunsang
오늘 실습은 insane-research와 pumasi 두 개로 합니다. 나머지는 필요할 때 같은 화면에서 설치합니다.
```
지금 보낼 말:
```
했어요
```
백업 문장(막혔을 때만 지금 보낼 말로 보여 준다):
```
오늘 쓸 GPTaku 플러그인 13개를 설치해 줘
```
실행(백업 문장을 받았을 때): 설치 묶음 13개를 `<codex> plugin add <이름>@gptaku-plugins`로 차례로 설치한다(gptaku-core 먼저, 승인을 요청해 한 번에 실행). 끝나면 `<codex> plugin list`에서 13줄이 `installed, enabled`인지 보여 준다.
확인할 것: 13개가 설치됨으로 보이는지. 특히 insane-research와 pumasi.

### 단계 3. 새 대화로 옮기기
보내기 전에 `progress.json`을 `current_block = "block2"`, `step = "새 대화"`로 적는다.
단계 2의 확인(`했어요`를 받고 `plugin list`로 읽은 한 줄, 또는 백업 문장 실행 결과와 확인할 것) 바로 아래, 화면 안내 앞에 사용 안내를 붙인다. 자동 확인에서 13개가 이미 설치돼 있어 단계 3부터 시작할 때도 붙인다.
사용 안내(이 글 그대로):
```
설치한 플러그인은 요청문 맨 앞에 이름을 붙여 부릅니다.
- insane-research: 요청문을 'insane-research로'로 시작하면 여러 출처를 찾아 조사합니다. 블록 3 첫 요청문이 이렇게 시작합니다.
- pumasi: 요청문을 'pumasi:image로'로 시작하면 그림을 만들어 저장합니다. 블록 3에서 고른 이슈의 그림을 이렇게 만듭니다.
- 나머지 플러그인도 같은 방법으로 이름을 붙여 부릅니다. 이름을 빼면 Codex 기본 기능으로 합니다.
```
화면 안내(이 글 그대로):
```
플러그인은 새 대화부터 쓰입니다.
1. 왼쪽 목록에서 프로젝트 이름(1교시-Codex-시작하기)을 눌러 새 대화를 엽니다.
2. 새 대화에 아래 말을 보냅니다. 블록 2 확인과 블록 3이 이어서 나옵니다.
```
지금 보낼 말 (새 대화에서):
```
@lab1
```
새 대화에서 `@lab1`을 받으면 stop-protocol의 "다시 들어왔을 때"대로 묻지 않고 블록 확인 + block3 시작 답을 보여 준다.

### 막히면
| 증상 | 이렇게 말해 보세요 / 할 일 |
|---|---|
| 화면에서 마켓 등록·설치가 안 된다(`도와줘`) | 단계 1이면 `GPTaku 플러그인 마켓을 등록해 줘`, 단계 2면 `오늘 쓸 GPTaku 플러그인 13개를 설치해 줘`를 지금 보낼 말로 |
| 승인 창을 거부해 버렸다 | 같은 문장을 다시 보내고 이번엔 승인 |
| 플러그인 화면에 GPTaku 플러그인이 없다 | 앱을 완전히 끄고 다시 켬 → 그래도 없으면 `GPTaku 플러그인 마켓을 등록해 줘` |
| git 준비가 안 됐다(`progress.json`의 `git`이 `"fail"`, 마켓 등록이 git 오류로 실패) | 손을 들어 보조강사에게 알린다(로그: `%LOCALAPPDATA%\workmate\git-setup.log`). 기다리지 않고 강사 화면 시연을 보고 block3으로 넘어간다 |
| 회사망에서 github.com이 막혔다 | 설치는 건너뛰고 강사 화면 시연을 봅니다. block3은 플러그인 이름 없이 같은 요청을 보내 기본 기능으로 해 봅니다 |
| 플러그인 이름을 넣었는데 안 쓰인다 | 새 대화에서 보냈는지 확인. 아니면 새 대화를 열고 다시 |

### 모범 결과
없음. 플러그인 화면 또는 `codex plugin list` 결과로 확인한다.

## 블록 확인
- 확인 체크(직접 확인한다): ① 지금 대화가 새 대화다 ② 이 대화에서 쓸 수 있는 스킬 목록에 `insane-research:insane-research-main`과 `pumasi:image`가 보인다(보이지 않으면 Codex 명령으로 `plugin list`를 읽어 설치 여부를 확인한다) ③ 나머지 11개(gptaku-core 포함)는 설치됨으로 한 줄 확인
- 핵심: "플러그인은 한 번 설치하면 어느 폴더에서든 씁니다. 요청문에 플러그인 이름을 넣으면 그 기능을 씁니다."
