---
name: lab1
description: 테스 Codex 교육 1교시(Codex 시작하기) 안내. 참가자가 `@lab1`을 보내면 읽는다. 폴더 둘러보기 → 가짜 다운로드 폴더 정리로 5단계 한 바퀴(지우기 거절 연습 포함) → 앱 설정 화면에서 gptaku-plugins 마켓 등록·플러그인 목록 소개·insane-research·pumasi 설치(insane-search 선택) → 오늘 화제 이슈 리서치·설명 그림·HTML 한 장 설명 자료 → 정리를 블록마다 설명→요청문→확인 순서로 멈춰 가며 안내한다.
---

# lab1 — 1교시 · Codex 시작하기

**먼저 `.agents/skills/_common/stop-protocol.md`를 읽고 그 진행 규칙을 지킨다.** 블록마다 A → 멈춤 → B(요청문마다 멈춤) → C → 멈춤.

## 블록

| 블록 | 파일 | 5단계 | 강사용 대략 시간 |
|---|---|---|---|
| block0 폴더 둘러보기 | `references/block0-start.md` | 업무 파악 맛보기 | 약 5분 |
| block1 다운로드 폴더 정리 | `references/block1-downloads.md` | 업무 파악→기획→만들기→검토→개선 한 바퀴 | 약 20분 |
| block2 플러그인 설치 | `references/block2-plugins.md` | — | 약 7분 |
| block3 오늘 이슈 설명 자료 만들기 | `references/block3-onepager.md` | 만들기·검토 | 약 15분 |
| block4 정리 | `references/block4-wrap.md` | — | 약 3분 |

시간 표는 강사용이다. 참가자에게 분 단위 시간을 말하지 않는다.

## 시작
1. `progress.json`을 연다(없으면 `_common/stop-protocol.md`의 기본값으로 만든다).
2. `current_lab`이 `"lab1"`이고 `current_block`이 있으면 stop-protocol의 "다시 들어왔을 때" 번호 선택지를 보여 주고 멈춘다.
3. 아니면 `current_lab = "lab1"`, `current_block = "block0"`, `phase = "A"`로 적고 아래 **전체 보기**를 그대로 보여 준 뒤, 바로 이어서 block0의 A를 한다(전체 보기 + block0 A가 첫 답 하나다).

## 전체 보기 (그대로 출력)

```
1교시 — Codex 시작하기

블록 0. 폴더 둘러보기 — Codex가 이 폴더의 파일을 읽고 설명합니다
블록 1. 다운로드 폴더 정리 — 업무 파악 → 기획 → 만들기 → 검토 → 개선 한 바퀴
        그리고 "지워 줘"를 거절해 보기
블록 2. 플러그인 설치 — 마켓 등록, 플러그인 목록 보기, insane-research·pumasi 설치
블록 3. 오늘 이슈 설명 자료 만들기 — 이슈 찾기 → 하나 고르기 → 그림 → HTML 한 장
블록 4. 정리 — 오늘 남은 파일을 5단계로 보기

끝나면 남는 것: 정리된 downloads 폴더, 설치된 플러그인 2개(insane-search까지 3개),
outputs 폴더의 계획.md · 정리결과.md · 오늘이슈.md · 이슈그림.png · 이슈설명.html · 1교시-정리.md
진행: 설명 → '다음' → 요청문 복사해 보내기 → 결과 확인 → '다음'
막히면 '도와줘', 시간이 모자라면 '건너뛰기'(모범 결과가 있는 단계는 모범 결과로,
이슈 찾기는 찾은 내용만 짧게 저장하고 넘어감)
```

## 블록 진행
- 블록 파일의 `## A`, `## B`, `## C` 절을 단계에 맞춰 읽는다. 한 턴에 한 절만.
- B의 요청문은 블록 파일에 적힌 문구를 **글자 그대로** 코드 블록으로 보여 준다(강사 화면과 같아야 한다). `{번호}`처럼 중괄호로 표시된 곳만 참가자가 고른 값으로 채운다. 표를 "그대로 보여 준다"고 적힌 곳(block2 A의 플러그인 표)은 표 5줄 제한의 예외다.
- block4의 C가 끝나면 `done`에 `"lab1"`을 추가하고, `current_lab`·`current_block`·`phase`를 `null`로 적는다. 마지막 줄은 block4 파일에 적힌 문장 그대로.
