---
name: lab1
description: 테스 Codex 교육 1교시(Codex 시작하기) 안내. 참가자가 `@lab1`을 보내면 읽는다. 폴더 둘러보기 → 데모 다운로드 폴더 정리로 5단계 한 바퀴(지우기 거절 연습 포함) → 앱 설정 화면에서 gptaku-plugins 마켓 등록·플러그인 목록 소개·쓸 만한 13개 설치(gptaku-core 포함, 실습은 insane-research·pumasi) → 오늘 화제 이슈 리서치·설명 그림·HTML 한 장 설명 자료 → 정리를 안내한다. 답마다 맨 아래에 참가자가 보낼 말 하나만 보여 주고 멈춘다.
---

# lab1 — 1교시 · Codex 시작하기

**먼저 `.agents/skills/_common/stop-protocol.md`를 읽고 그 진행 규칙을 지킨다.** 답마다 맨 아래에 `지금 보낼 말` 하나만 보여 주고 멈춘다. 블록 시작 답 = 짧은 설명 + 첫 요청문, 요청문을 받으면 실행 + 확인할 것 + 다음 요청문, 블록 마지막 요청문 뒤에는 블록 확인 + 다음 블록 시작 답.

## 블록

| 블록 | 파일 | 5단계 | 강사용 대략 시간 |
|---|---|---|---|
| block0 폴더 둘러보기 | `references/block0-start.md` | 업무 파악 맛보기 | 약 5분 |
| block1 다운로드 폴더 정리 | `references/block1-downloads.md` | 업무 파악→기획→만들기→검토→개선 한 바퀴 | 약 20분 |
| block2 플러그인 설치 | `references/block2-plugins.md` | — | 약 7분 |
| block3 오늘 이슈 설명 자료 만들기 | `references/block3-onepager.md` | 만들기·검토 | 약 15분 |
| block4 정리 | `references/block4-wrap.md` | — | 약 3분 |

시간 표는 강사용이다. 참가자에게 분 단위 시간을 말하지 않는다.

## 시작
1. `progress.json`을 연다(없으면 `_common/stop-protocol.md`의 기본값으로 만든다).
2. **git 준비 (Windows만, `progress.json`의 `git`이 경로나 `"ok"`가 아닐 때만).** block2 플러그인 마켓 등록에 git이 필요하다. 답을 쓰기 전에 PowerShell에서 `git --version`을 실행한다.
   - 되면 `git = "ok"`로 적는다.
   - 안 되면 `powershell -NoProfile -ExecutionPolicy Bypass -File .agents\skills\lab1\scripts\ensure-git.ps1`을 **승인을 요청해** 실행한다(인터넷과 사용자 폴더를 쓴다. 관리자 권한은 쓰지 않는다. 일시 오류는 스크립트가 알아서 다시 시도하며 최대 3분). 승인 이유는 `플러그인 마켓 등록에 필요한 git을 준비합니다`로 적는다.
   - 출력 마지막 줄이 `GIT_OK <경로>`면 `git`에 그 경로를, `GIT_FAIL`이면 `"fail"`을, 참가자가 승인을 거부하면 `"skip"`을 적는다.
   - 결과는 화면에 말하지 않는다(실패해도). 그대로 다음 순서로 간다. Mac은 이 단계를 건너뛴다.
3. `current_lab`이 `"lab1"`이고 `current_block`이 있으면 stop-protocol의 "다시 들어왔을 때" 번호 선택지를 보여 주고 멈춘다.
4. 아니면 `current_lab = "lab1"`, `current_block = "block0"`, `step = 1`로 적고 아래 **전체 보기**를 그대로 보여 준 뒤, 바로 이어서 block0의 시작 답을 한다(전체 보기 + block0 시작 답이 첫 답 하나다. 맨 아래 지금 보낼 말은 block0의 첫 요청문).

## 전체 보기 (그대로 출력)

```
1교시 — Codex 시작하기

블록 0. 폴더 둘러보기 — Codex가 이 폴더의 파일을 읽고 설명합니다
블록 1. 다운로드 폴더 정리 — 업무 파악 → 기획 → 만들기 → 검토 → 개선 한 바퀴
        그리고 지우기 요청을 거절해 보기
블록 2. 플러그인 설치 — 마켓 등록, 플러그인 목록 보기, insane-research·pumasi 설치
블록 3. 오늘 이슈 설명 자료 만들기 — 이슈 찾기 → 하나 고르기 → 그림 → HTML 한 장
블록 4. 정리 — 오늘 남은 파일을 5단계로 보기

끝나면 남는 것: 정리된 downloads 폴더, 설치된 플러그인 13개,
outputs 폴더의 계획.md · 정리결과.md · 오늘이슈.md · 이슈그림.png · 이슈설명.html · 1교시-정리.md
진행: 답 맨 아래 '지금 보낼 말'을 그대로 복사해 보내기 → 결과 확인 → 다음 보낼 말
      앱 화면에서 하는 단계만 '했어요'를 보냅니다
막히면 '도와줘', 시간이 모자라면 '건너뛰기'(모범 결과가 있는 단계는 모범 결과로,
이슈 찾기는 찾은 내용만 짧게 저장하고 넘어감)
```

## 블록 진행
- 블록 파일은 `## 시작 답`, `## 차례`(`### 단계 1`, `### 단계 2` …), `## 블록 확인` 절로 되어 있다. 매 턴 `progress.json`의 `current_block`·`step`에 맞는 절을 다시 연다.
- 요청문은 블록 파일에 적힌 문구를 **글자 그대로** 지금 보낼 말 코드 블록으로 보여 준다(강사 화면과 같아야 한다). `{번호}`처럼 중괄호로 표시된 곳만 참가자가 고른 값으로 채운다. 표를 "그대로 보여 준다"고 적힌 곳(block2 단계 2의 플러그인 표)은 표 5줄 제한의 예외다.
- block4의 블록 확인이 끝나면 `done`에 `"lab1"`을 추가하고, `current_lab`·`current_block`·`step`을 `null`로 적는다. 마지막 줄은 block4 파일에 적힌 문장 그대로.
