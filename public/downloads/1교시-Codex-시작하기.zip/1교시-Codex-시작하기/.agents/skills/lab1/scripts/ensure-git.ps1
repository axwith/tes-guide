﻿# ensure-git.ps1 — git이 없으면 관리자 권한 없이 사용자 폴더에 조용히 설치한다 (Windows PowerShell 5.1 이상).
# 화면 출력은 마지막 한 줄뿐: "GIT_OK <git.exe 경로>" 또는 "GIT_FAIL <이유>". 자세한 시도 기록은 로그 파일에만 남긴다.
#   로그: %LOCALAPPDATA%\workmate\git-setup.log   찾은 경로: %LOCALAPPDATA%\workmate\git-path.txt
# 일시 오류(408·409·425·429·5xx·연결 끊김·깨진 zip)는 2·4·8초(+무작위 0~1초) 기다렸다 다시 시도하고,
# 안 되면 다음 소스로 넘어간다: MinGit 고정 버전 → GitHub API 최신 MinGit → winget(사용자 범위). 전체 상한 3분.
param([switch]$DryRun)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

$MinGitVer = '2.56.1'
$FixedUrl  = if ($env:WORKMATE_MINGIT_URL) { $env:WORKMATE_MINGIT_URL } else { "https://github.com/git-for-windows/git/releases/download/v$MinGitVer.windows.1/MinGit-$MinGitVer-64-bit.zip" }
$ApiUrl    = 'https://api.github.com/repos/git-for-windows/git/releases/latest'
$GitHome   = Join-Path $env:LOCALAPPDATA 'Programs\Git'
$StateDir  = Join-Path $env:LOCALAPPDATA 'workmate'
$Log       = Join-Path $StateDir 'git-setup.log'
$PathFile  = Join-Path $StateDir 'git-path.txt'
$Deadline  = (Get-Date).AddMinutes(3)
$Rand      = New-Object System.Random

New-Item -ItemType Directory -Force -Path $StateDir | Out-Null
function Log($m) { Add-Content -Path $Log -Value ("{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m) -Encoding UTF8 }

function Test-Git($exe) {
  if (-not $exe -or -not (Test-Path $exe)) { return $false }
  try { $v = & $exe --version 2>$null; return ($LASTEXITCODE -eq 0 -and "$v" -match 'git version') } catch { return $false }
}

function Find-Git {
  $c = Get-Command git -ErrorAction SilentlyContinue
  if ($c -and (Test-Git $c.Source)) { return $c.Source }
  $cands = @()
  if (Test-Path $PathFile) { $cands += (Get-Content $PathFile -TotalCount 1) }
  $cands += (Join-Path $GitHome 'cmd\git.exe'), (Join-Path $env:ProgramFiles 'Git\cmd\git.exe'), (Join-Path $env:LOCALAPPDATA 'Programs\Git\bin\git.exe')
  foreach ($p in $cands) { if (Test-Git $p) { return $p } }
  return $null
}

function Done($exe, $how) {
  $dir = Split-Path $exe -Parent
  $up = [Environment]::GetEnvironmentVariable('Path', 'User')
  if (-not (($up -split ';') -contains $dir)) {
    [Environment]::SetEnvironmentVariable('Path', ((@($up, $dir) | Where-Object { $_ }) -join ';'), 'User')
  }
  Set-Content -Path $PathFile -Value $exe -Encoding UTF8
  Log "결과: 성공 $exe 방법 $how"
  Write-Output "GIT_OK $exe"
  exit 0
}

function Get-Code($err) {
  try { $r = $err.Exception.Response; if ($r) { return [int]$r.StatusCode } } catch {}
  return 0   # 응답 없음(연결 끊김·DNS·시간 초과)
}
function Is-Retryable($code) { return ($code -eq 0 -or @(408, 409, 425, 429, 500, 502, 503, 504) -contains $code) }
function Wait-Backoff($n, $err) {
  $s = [Math]::Min(15, 2 * [Math]::Pow(2, $n - 1)) + $Rand.NextDouble()
  try { $ra = $err.Exception.Response.Headers['Retry-After']; if ($ra -match '^\d+$') { $s = [Math]::Min(30, [int]$ra) } } catch {}
  if ((Get-Date).AddSeconds($s) -gt $Deadline) { return $false }
  if (-not $DryRun) { Start-Sleep -Milliseconds ([int]($s * 1000)) }
  return $true
}

# 내려받기 → zip 확인 → 사용자 폴더에 풀기. 성공하면 git.exe 경로, 아니면 $null
function Install-MinGit($url, $src) {
  for ($n = 1; $n -le 4; $n++) {
    if ((Get-Date) -gt $Deadline) { Log "$src 시간 상한(3분) 도달"; return $null }
    $zip = Join-Path $env:TEMP ("mingit-" + [guid]::NewGuid().ToString('N').Substring(0, 8) + '.zip')
    try {
      if ($DryRun) { throw (New-Object System.Net.WebException 'DryRun') }
      Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $zip -TimeoutSec 120
      Add-Type -AssemblyName System.IO.Compression.FileSystem
      $z = [IO.Compression.ZipFile]::OpenRead($zip); $cnt = $z.Entries.Count; $z.Dispose()
      if ($cnt -lt 10) { throw (New-Object System.IO.InvalidDataException "zip 항목 $cnt개") }
      Expand-Archive -Path $zip -DestinationPath $GitHome -Force
      Remove-Item $zip -Force -ErrorAction SilentlyContinue
      $exe = Join-Path $GitHome 'cmd\git.exe'
      if (Test-Git $exe) { Log "$src 시도$n/4 성공"; return $exe }
      Log "$src 시도$n/4 풀었지만 git 실행 실패"; return $null
    } catch {
      Remove-Item $zip -Force -ErrorAction SilentlyContinue
      $code = Get-Code $_
      if ($_.Exception -is [System.IO.InvalidDataException]) { $code = 0 }
      Log ("$src 시도$n/4 실패 HTTP {0} {1}" -f $code, $_.Exception.Message)
      if (-not (Is-Retryable $code)) { return $null }
      if ($n -lt 4 -and -not (Wait-Backoff $n $_)) { Log "$src 시간 상한(3분) 도달"; return $null }
    }
  }
  return $null
}

function Get-LatestMinGitUrl {
  for ($n = 1; $n -le 3; $n++) {
    try {
      if ($DryRun) { throw (New-Object System.Net.WebException 'DryRun') }
      $rel = Invoke-RestMethod -UseBasicParsing -Uri $ApiUrl -TimeoutSec 20
      $a = $rel.assets | Where-Object { $_.name -match '^MinGit-[\d\.]+-64-bit\.zip$' } | Select-Object -First 1
      if ($a) { return $a.browser_download_url }
      Log 'API 응답에 MinGit 없음'; return $null
    } catch {
      $code = Get-Code $_
      Log ("API 시도$n/3 실패 HTTP {0} {1}" -f $code, $_.Exception.Message)
      if (-not (Is-Retryable $code)) { return $null }
      if ($n -lt 3 -and -not (Wait-Backoff $n $_)) { return $null }
    }
  }
  return $null
}

Log '--- git 준비 시작'
$found = Find-Git
if ($found) { Done $found '이미 있음' }

$exe = Install-MinGit $FixedUrl "MinGit-$MinGitVer"
if ($exe) { Done $exe "MinGit-$MinGitVer" }

$latest = Get-LatestMinGitUrl
if ($latest -and $latest -ne $FixedUrl) {
  $exe = Install-MinGit $latest 'MinGit-최신'
  if ($exe) { Done $exe 'MinGit-최신' }
}

$wg = Get-Command winget -ErrorAction SilentlyContinue
if ($wg -and -not $DryRun) {
  for ($n = 1; $n -le 2; $n++) {
    if ((Get-Date) -gt $Deadline) { break }
    $out = & winget install --id Git.Git -e --source winget --scope user --silent --accept-package-agreements --accept-source-agreements --disable-interactivity 2>&1
    Log ("winget 시도$n/2 종료코드 0x{0:X8}" -f $LASTEXITCODE)
    $found = Find-Git
    if ($found) { Done $found 'winget' }
    if ($n -lt 2) { Start-Sleep -Seconds 3 }
  }
}

Log '결과: 실패'
Write-Output "GIT_FAIL 로그 $Log"
exit 1
