# 모범 결과 (막혔을 때)

참가자가 막히거나 시간이 모자랄 때 해당 단계 결과를 `outputs/`로 복사하고 다음 단계로 넘어간다.
Codex가 만들 결과와 모양이 똑같을 필요는 없다.
HTML은 모두 단일 파일이고 외부 연결이 없다. 더블클릭하면 브라우저에서 열린다.

| 폴더 | STEP | 모범 결과 |
|------|------|------|
| `step1/` | STEP 1 ① 업무 파악 | `step1_data_overview.md` 파일·런 수·기간·파라미터 범위·빈 값 |
| `step2/` | STEP 2 ② 기획 | `관점.md` 관점 5개(지표·그림), `계획.md` 관점 1·2 계획과 가설 |
| `step3/` | STEP 3 ③ 만들기 — 분석 | `run_metrics.csv` 런별 지표 243행, `anomalies.md` 이상 구간 표(날짜·런 번호·숫자) |
| `step4/` | STEP 4 ③ 만들기 — 시각화 | `dashboard.html` 추이(세로선·이상 런 표시) + 정상·이상 분포 2장(색 범위 고정) |
| `step5/` | STEP 5 ④ 검토 | `review.md` 대조용 숫자 3개의 파일·줄 번호, 가설 확인, 원인 후보 표(근거·반대 증거) |
| `step6/` | STEP 6 ⑤ 개선 — 조정 | `adjust.html` DOE 효과·모델식·조합 2개와 계산기 값 |
| `step7/` | STEP 7 ⑤ 개선 — 고치기·보고 | `한장보고.md` 현상 → 근거 → 원인 후보 → 조정안 → 확인할 것 |
| `more/` | 더 해 보기 | `compare_maps.html`·`compare.md` 대표 런 6개·3공식 순위, `scatter.html` 산점도 |

STEP 3 이후는 앞 STEP 파일을 이어 쓴다. 건너뛸 때 앞 STEP 결과가 `outputs/`에 없으면 앞 STEP 파일도 함께 `outputs/`에 복사한다.
- STEP 3: `step2/계획.md`
- STEP 4: `step2/계획.md`, `step3/run_metrics.csv`, `step3/anomalies.md`
- STEP 5: STEP 4 목록 + `step4/dashboard.html`
- STEP 6: STEP 5 목록 + `step5/review.md`
- STEP 7: STEP 6 목록 + `step6/adjust.html`
STEP 7 "2번 그림만 고치기"는 각자 대시보드의 두 번째 그림이 기준이라 모범 결과가 따로 없다. 다른 그림이 그대로인지만 본다.

## 막혔을 때

| 증상 | 할 일 |
|------|------|
| 기획에서 Codex가 계산·그림까지 만들어 버림 | "계획만 세워 달라고 했어. 계획.md만 보여 줘". 시간 없으면 `step2/계획.md` 복사 |
| 어느 STEP이든 5분 넘게 걸림 | 기다리는 동안 `outputs/`에 파일이 생겼는지 본다. 7분 넘으면 해당 `stepN/`을 `outputs/`에 복사하고 다음 STEP으로 |
| Python이 없다고 함 | "PowerShell로 계산해 줘". 그래도 안 되면 `step3/` 복사 후 STEP 4로 |
| 대시보드에 10-29~30 극단값이 보임 | DOE 런이 섞였다. "runs.csv에 있는 생산 런만 써 줘" |
| 이상 구간에 숫자가 없음 | "구간마다 9월 중앙값 대비 몇 nm·몇 %인지 숫자로 적어 줘" |
| 히트맵들이 색이 다 비슷해 보임 | 색 범위를 런마다 자동으로 잡았다. "모든 런 같은 색 범위로 고정해 줘" |
| 원인을 단정함("spacing 때문이다") | "AGENTS.md 원인 후보 규칙대로 반대 증거와 확인할 것을 붙여 줘" |
| CH2 원인으로 heater_set만 보고 "변화 없음" | "heater_read와 heater_set의 차이를 런별로 계산해 편심 x와 같이 봐 줘" |
| 개선 단계에서 반범위로 직선 모델을 세움 | "중앙−가장자리(부호 있음)로 모델을 세우고 반범위는 계산기로 확인해 줘" |
| 계산기에서 목표 초과 | spacing 9.4면 pressure를 4.3 이상으로. 4.6 이상은 DOE 범위 밖(외삽 경고) |
| 계산기 평균이 보고서와 5 nm쯤 다름 | 계산기 "PM 뒤 RF 누적 시간"을 DOE 때 값(약 215 h)으로 맞추면 비슷해진다 |
| 시간이 남음 | `prompts.md` 더 해 보기 |
