---
name: lab2
description: 테스 Codex 교육 2교시(Codex 응용하기) 안내. 참가자가 `@lab2`를 보내면 읽는다. 연구소 장비 런 데이터(가상 증착 장비 막 두께)로 업무 파악 → 기획 → 만들기(분석·시각화) → 검토 → 개선(조정·고치기·보고) STEP을 안내한다. 화면마다 참가자가 보낼 말을 맨 아래 '지금 보낼 말' 하나로만 보여 준다.
---

# lab2 — 2교시 Codex 응용하기 · 연구소 장비 런 데이터 실습

**먼저 `.agents/skills/_common/stop-protocol.md`를 읽고 그 진행 규칙을 지킨다.** 화면 하나에 보낼 말 하나: 블록 시작 = 짧은 설명 + 지금 보낼 말(첫 요청문) → 요청문을 받으면 실행 + 확인할 것 + 지금 보낼 말(다음 요청문) → 블록 마지막 요청문 뒤에는 블록 확인 + 다음 블록 시작. 설명만 보여 주고 '다음'을 기다리지 않는다.

## 시작
1. `progress.json`을 연다(없으면 stop-protocol 기본값으로 만든다).
2. `current_lab`이 `"lab2"`이고 `current_block`이 있으면 stop-protocol의 "다시 들어왔을 때" 번호 선택지를 보여 주고 멈춘다.
3. 아니면 `references/block0-start.md`대로 한 답에 자동 준비 → 전체 보기 → STEP 1 시작 답(설명 + 지금 보낼 말)을 보여 준다. 과정 고르기 질문은 없다. 이 폴더는 연구소 과정 하나다.

## 블록 파일
- block0: `references/block0-start.md` (전체 보기·자동 준비)
- block1~block7: `references/steps.md` — 블록이 `## block1` … `## block7`로 나뉘고, 블록마다 `### 설명`, `### 요청문 1`(·`### 요청문 2`), `### 블록 확인` 절이 있다.
- block8: `references/block8-wrap.md` (정리)

경로 `data/`, `outputs/`, `tools/`, `checkpoints/`는 모두 이 폴더(`2교시-Codex-응용하기`) 맨 위 기준이다.

## 블록 (강사 화면 순서)

| 블록 | STEP | 5단계 |
|---|---|---|
| block0 | 전체 보기 | — |
| block1 | STEP 1 | ① 업무 파악 |
| block2 | STEP 2 | ② 기획 |
| block3 | STEP 3 | ③ 만들기 — 분석 |
| block4 | STEP 4 | ③ 만들기 — 시각화 |
| block5 | STEP 5 | ④ 검토 |
| block6 | STEP 6 | ⑤ 개선 — 조정 |
| block7 | STEP 7 | ⑤ 개선 — 고치기·보고 |
| block8 | 정리 | — |

## 진행 규칙 (2교시 추가)
- 요청문은 블록 파일 문구를 **글자 그대로** `지금 보낼 말:` 아래 코드 블록으로 보여 준다. 한 답에 하나만. 설명·확인할 것 문장 안에 다른 요청문을 인용하지 않는다. 모든 STEP을 **같은 대화**에서 이어 한다(앞 결과를 이어 쓰기 때문).
- 블록 마지막 요청문(`steps.md`에서 제목에 `블록 마지막`이 붙은 요청문)을 처리한 답은 보내기 전에 스스로 점검한다: `STEP N 확인`(①②③ 맞음/아님) · `비교:` · `핵심:` · 다음 블록 `### 설명` 코드 블록 · `지금 보낼 말:`(다음 블록 요청문 1) 다섯 가지가 모두 있어야 한다. 하나라도 빠졌으면 채운 뒤 보낸다.
- 참가자가 붙여 넣은 요청문을 실행할 때는 `AGENTS.md`의 분석 규칙(계산 정의·런 데이터 지표·그림 규칙·원인 후보 규칙·보고 규칙)대로 한다. 결과는 `outputs/`에 저장한다.
- 추이 그림은 `.agents/skills/run-trend/SKILL.md`, 웨이퍼 분포 그림은 `.agents/skills/thickness-map/SKILL.md`를 열어 따른다.
- 요청문 하나는 몇 분 안에 끝내는 것을 목표로 한다. 계산·그림은 스크립트 하나로 한 번에.
- "건너뛰기"면 블록 파일의 `모범 결과` 파일을 `checkpoints/lab2-research/stepN/`에서 `outputs/`로 복사한다. 앞 STEP 결과가 없으면 앞 STEP 모범 결과도 함께 복사한다(블록 파일에 적힌 목록).
- block8 요청문 처리 뒤 블록 확인까지 끝나면 `done`에 `"lab2"`를 추가하고 `current_lab`·`current_block`·`next_prompt`를 `null`로 적는다.
