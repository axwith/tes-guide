---
name: lab2
description: 테스 Codex 교육 2교시(Codex 응용하기) 안내. 참가자가 `@lab2`를 보내면 읽는다. 연구소 장비 런 데이터(가상 증착 장비 막 두께)로 업무 파악 → 기획 → 만들기(분석·시각화) → 검토 → 개선(조정·고치기·보고) STEP을 블록마다 설명→복사용 요청문→확인·모범 결과 순서로 멈춰 가며 안내한다.
---

# lab2 — 2교시 Codex 응용하기 · 연구소 장비 런 데이터 실습

**먼저 `.agents/skills/_common/stop-protocol.md`를 읽고 그 진행 규칙을 지킨다.** 블록마다 A → 멈춤 → B(요청문마다 멈춤) → C → 멈춤.

## 시작
1. `progress.json`을 연다(없으면 stop-protocol 기본값으로 만든다).
2. `current_lab`이 `"lab2"`이고 `current_block`이 있으면 stop-protocol의 "다시 들어왔을 때" 번호 선택지를 보여 주고 멈춘다.
3. 아니면 `current_lab = "lab2"`, `current_block = "block0"`, `phase = "A"`로 적고 `references/block0-start.md`의 A(2교시 전체 보기)를 보여 주고 멈춘다. 과정 고르기 질문은 없다. 이 폴더는 연구소 과정 하나다.

## 블록 파일
- block0: `references/block0-start.md` (전체 보기·자동 준비)
- block1~block7: `references/steps.md` — 블록이 `## block1` … `## block7`로 나뉘고, 블록마다 `### A`, `### B`, `### C` 절이 있다. stop-protocol의 "블록 파일의 A 절"은 이 `### A`를 뜻한다.
- block8: `references/block8-wrap.md` (정리)

경로 `data/`, `outputs/`, `tools/`, `checkpoints/`는 모두 이 폴더(`2교시-Codex-응용하기`) 맨 위 기준이다.

## 블록 (강사 화면 순서)

| 블록 | STEP | 5단계 |
|---|---|---|
| block0 | 전체 보기 | — |
| block1 | STEP 1 | ① 업무 파악 |
| block2 | STEP 2 | ② 기획 |
| block3 | STEP 3 | ③ 만들기 — 분석 |
| block4 | STEP 4 | ③ 만들기 — 시각화 |
| block5 | STEP 5 | ④ 검토 |
| block6 | STEP 6 | ⑤ 개선 — 조정 |
| block7 | STEP 7 | ⑤ 개선 — 고치기·보고 |
| block8 | 정리 | — |

## 진행 규칙 (2교시 추가)
- 요청문은 블록 파일 문구를 **글자 그대로** 코드 블록으로 보여 준다. 모든 STEP을 **같은 대화**에서 이어 한다(앞 결과를 이어 쓰기 때문).
- 참가자가 붙여 넣은 요청문을 실행할 때는 `AGENTS.md`의 분석 규칙(계산 정의·런 데이터 지표·그림 규칙·원인 후보 규칙·보고 규칙)대로 한다. 결과는 `outputs/`에 저장한다.
- 추이 그림은 `.agents/skills/run-trend/SKILL.md`, 웨이퍼 분포 그림은 `.agents/skills/thickness-map/SKILL.md`를 열어 따른다.
- 요청문 하나는 몇 분 안에 끝내는 것을 목표로 한다. 계산·그림은 스크립트 하나로 한 번에.
- "건너뛰기"면 블록 파일의 `모범 결과` 파일을 `checkpoints/lab2-research/stepN/`에서 `outputs/`로 복사한다. 앞 STEP 결과가 없으면 앞 STEP 모범 결과도 함께 복사한다(블록 파일에 적힌 목록).
- block8의 C가 끝나면 `done`에 `"lab2"`를 추가하고 `current_lab`·`current_block`·`phase`를 `null`로 적는다.
